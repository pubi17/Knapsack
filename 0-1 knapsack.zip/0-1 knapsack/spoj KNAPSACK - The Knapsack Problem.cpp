#include<bits/stdc++.h>
using namespace std;
long long int n;
long long int weight[2002],price[2002];
long long int dp[2002][2002];

int knapsack(long long int i,long long int w)
{
    if(i>=n) return 0;

    else if(dp[i][w]!=-1) return dp[i][w];

    else{
        int profit1,profit2;

        profit1=knapsack(i+1,w);

        if(weight[i]<=w){ profit2=price[i]+knapsack(i+1,w-weight[i]);}

        else {profit2=0;}

            return dp[i][w]=max(profit1,profit2);
    }
}
int main()
{
   long long int w,i;
    memset(dp, -1, sizeof(dp));
    ios::sync_with_stdio(0);
    cin>>w>>n;

    for(i=0;i<n;i++) cin>>price[i]>>weight[i];

    cout<<knapsack(0,w)<<endl;
    return 0;
}
