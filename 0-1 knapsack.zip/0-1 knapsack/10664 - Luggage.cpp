#include<bits/stdc++.h>
using namespace std;
void knap(string s)
{
    stringstream ss(s);//sentence splits into word
        int k,sum=0;

        while(ss>>k)
        {
            sum+=k;
        }
        if(sum%2==0) cout<<"YES"<<endl;

        else cout<<"NO"<<endl;
}

int main()
{
    int t;
    string s;
    cin>>t;
    cin.ignore();
    for(int i=0;i<t;i++){
        getline(cin,s);

knap(s);
    }
    return 0;
}

