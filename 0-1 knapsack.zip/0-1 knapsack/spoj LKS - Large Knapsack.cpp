#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
ll n;
ll knapsack(vector< ll >value, vector< ll >weight, ll CAP ){
	//ll n = value.size();
	//cout<<n<<" n"<<endl;
	vector <ll> dp(CAP+1);
	for(ll i =0; i< n; i++){
		for(ll a = CAP; a >= weight[i]; --a){
			dp[a] = max(dp[a], dp[a - weight[i]] + value[i]);
		}
	}
	return dp[CAP];
}

int main(){
	ll CAP;
	scanf("%lld %lld",&CAP, &n);
	vector <ll> value(n), weight(n);

	for(ll i = 0; i < n; i++){
		scanf("%lld %lld",&value[i],&weight[i]);
	}
	printf("%lld\n",knapsack(value, weight, CAP));
	return 0;
}
