#include<bits/stdc++.h>
using namespace std;
int n;
int weight[1000],price[1000];
int dp[1000][1000];

int knapsack(int i,int w)
{
    if(i>=n) return 0;
    else if(dp[i][w]!=-1) return dp[i][w];

    else

    {
        int profit1,profit2;
        profit1=knapsack(i+1,w);
        if(weight[i]<=w)
            profit2=price[i]+knapsack(i+1,w-weight[i]);
            else profit2=0;

            return dp[i][w]=max(profit1,profit2);

    }

}
int main()
{
    int t,w,i;
    memset(dp, -1, sizeof(dp));
    ios::sync_with_stdio(0);
    cin>>t;
    cout<<endl;
    while(t--)
    {
        cin>>w>>n;
        for (i=0;i<n;i++) cin>>weight[i]>>price[i];

cout<<"Hey stupid robber, you can get "<<knapsack(0,w)<<"."<<endl;
    }
    return 0;
}
