///Time-Complexity: O(n*w)
///Space-Complexity: O(n*w)

#include<bits/stdc++.h>
using namespace std;

int n,s;
int weight[100], price[100];
int dp[100][100];

int knapsack(int i, int w){
     if(i>=n) return 0;
     else if(dp[i][w]!=-1) return dp[i][w];
     else{
            int profit2;
          int profit1=knapsack(i+1, w);//next step r price na niye
          //price[i]+knapsack(i+1,w-weight[i]) next r price niye
          //max(na niye,niye) ->duitar moddhe jetir price boro seta nibo

          //profit1=knap(i+1,w) ->i th step r profit
          //profit2=price[i]+knap(i+1,w-w8[i]) ->ith and (i+1)th step r profit
          //max(profit1,profit2)

          if(w>=weight[i]){
                s+=weight[i];
                profit2=price[i]+knapsack(i+1, w-weight[i]);
          }
     else
        profit2=0;
     return dp[i][w]=max(profit1,profit2);


     }
}

int main(){
     int i, limit;
     cin >> limit>>n;
     for(i=0; i<n; ++i) cin >> weight[i] >> price[i];

     memset(dp, -1, sizeof dp);
     int maxfun=knapsack(0, limit);
     int minmoney=0;
     for(i=0;i<=limit;i++)
     {
         if(dp[n][i]==maxfun){
            minmoney=i;
            break;            \\\\problem
         }
     }
     cout<<maxfun<<" "<<minmoney<<endl;

}
